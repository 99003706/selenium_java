package StudentManagementApp;

import java.sql.PreparedStatement;
import java.sql.Statement;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;

public class Studentdao {

	public static boolean insertStudenttoDb(Student st)
	{
		//JDBC code
		boolean f =false;
		
		try {
			
			Connection con =  (Connection) CP.createC();
			String q ="insert into students(sname ,sphone, scity) values(? ? ?)";
			//prepared statement 
			PreparedStatement pstmt = con.prepareStatement(q);
			// set the value of parameter 
			
			pstmt.setString(1,st.getStudentname());
			pstmt.setString(2, st.getStudentphone());
			pstmt.setString(3, st.getStudentcity());
			
			//execute query 
			pstmt.executeUpdate();
			f=true;
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
	}

	public static boolean deleteStudent(int userId) {
		// TODO Auto-generated method stub
boolean f =false;
		
		try {
			
			Connection con =  (Connection) CP.createC();
			String q ="delete from students where sid=?";
			//prepared statement 
			PreparedStatement pstmt = con.prepareStatement(q);
			// set the value of parameter 
			
			pstmt.setInt(1,userId);
			
			//execute query 
			pstmt.executeUpdate();
			f=true;
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return f;
		
	}

	public static void showAllStudent() {
		// TODO Auto-generated method stub

		
		try {
			
			Connection con =  (Connection) CP.createC();
			String q ="select *from students;";
			Statement stmt =con.createStatement();
			ResultSet set=(ResultSet) stmt.executeQuery(q);
			
			while (set.next())
			{
				int id =set.getInt(1);
				String name =set.getString(2);
				String phone =set.getString(3);
				String city  =set.getString("scity");
				
				System.out.println("ID:" +id);
				System.out.println("Name:" +name);
				System.out.println("Phone:" +phone);
				System.out.println("City:" +city);
				System.out.println("++++++++++++++++++++++++++++");
			}
			 
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
}