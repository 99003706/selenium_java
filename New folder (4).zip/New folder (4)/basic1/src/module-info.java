module basic1 {
	requires okio;
}