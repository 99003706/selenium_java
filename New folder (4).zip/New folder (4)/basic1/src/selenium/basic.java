package selenium;

import org.openqa.selenium.WebDriver;

public class basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("welcome to selenium training");
		System.setProperty("webdriver.chrome.driver"," C:\\Users\\Training\\Downloads\\chromedriver_win32");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Frames.html");
	}

}
