package com.ltts.genesis;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;


public class BasicMaven {
	@Test
	public void login() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//Driver//chromedriver.exe");
		 WebDriver driver=new FirefoxDriver();
		 driver.get("https://www.ibef.org/ibefusers/signUpRequest");
		
	}
}
