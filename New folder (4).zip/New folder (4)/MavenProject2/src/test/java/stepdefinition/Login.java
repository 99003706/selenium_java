package stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login {
	@Given("I will launchchrome browser")
	public void i_will_launchchrome_browser() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Training\\Downloads\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
	    
	}

	@Given("I enter the url")
	public void i_enter_the_url() {
	}
	
	    

	@When("I enter username")
	public void i_enter_username() {
	    
	}

	@When("I enter password")
	public void i_enter_password() {
	    
	}

	@When("I click on login button")
	public void i_click_on_login_button() {
	   
	}

	@Then("I should see home screen")
	public void i_should_see_home_screen() {
	    
	}

	@Given("I want to write a step with name1")
	public void i_want_to_write_a_step_with_name1() {
	   
	}

	@When("I check for the {int} in step")
	public void i_check_for_the_in_step(Integer int1) {
	    
	}

	@Then("I verify the success in step")
	public void i_verify_the_success_in_step() {
	    
	}

	@Given("I want to write a step with name2")
	public void i_want_to_write_a_step_with_name2() {
	 
	}

	@Then("I verify the Fail in step")
	public void i_verify_the_fail_in_step() {
	  
	}

}
