package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class basic {
	 WebDriver driver;
   @Test(priority=1)
	public void home()
	{
//	  
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Training\\Downloads\\geckodriver-v0.29.0-win32\\geckodriver.exe");
//		
		 WebDriver driver=new FirefoxDriver();
		    driver.get("https://opensource-demo.orangehrmlive.com/");
	}

	@Test(priority=2)
	public void login()
	{
		 WebDriver driver=new FirefoxDriver();
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		
	}
	 
    @Test(priority=3)
	public void logout()
	{
    	 WebDriver driver=new FirefoxDriver();
		driver.findElement(By.id("welcome")).click();
	}
	
}
