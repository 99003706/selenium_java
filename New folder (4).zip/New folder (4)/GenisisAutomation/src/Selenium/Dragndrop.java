package Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Dragndrop {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Training\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		
		//page opening url
		driver.get("https://dhtmlx.com/docs/products/dhtmlxTree/");
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,400)");

		
		WebElement src=driver.findElement(By.xpath("//span[text()='Ian Rankin']"));
		WebElement dst=driver.findElement(By.xpath("//li[text()='Zend Framework in Action']"));
		Actions act= new Actions(driver);
		
		act.clickAndHold(src)
		.pause(Duration.ofSeconds(2))
		.moveToElement(dst)
		.pause(Duration.ofSeconds(2))
	
		.release()
		.build()
		.perform();
		
		
	

	}

}
