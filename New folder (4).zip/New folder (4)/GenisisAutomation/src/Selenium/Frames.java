package Selenium;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

 

public class Frames {

	public static void main(String[] args) throws Exception {

		System.out.println("Welcome to selenium");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Training\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//page opening url
		driver.get("http://demo.automationtesting.in/Frames.html");
		driver.manage().window().maximize();

		

		driver.findElement(By.linkText("Iframe with in an Iframe")).click();

		Thread.sleep(500);

		

		//Entering into Larger frame

		WebElement fr1 = driver.findElement(By.xpath("//*[@id=\"Multiple\"]/iframe"));

		driver.switchTo().frame(fr1);

		

		//Entering into inner frame

		WebElement fr2 = driver.findElement(By.xpath("/html/body/section/div/div/iframe"));

		driver.switchTo().frame(fr2);

		driver.findElement(By.xpath("/html/body/section/div/div/div/input")).sendKeys("Lalit Bhardwaj");

		

	}

}