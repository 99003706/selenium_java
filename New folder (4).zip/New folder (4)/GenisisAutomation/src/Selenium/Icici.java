package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Icici {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("welcome to selenium training");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Training\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//page opening url
		driver.get("https://loan.icicibank.com/asset-portal-all/check-eligibility?loanType=al&WT.mc_id=Desk_OAPN_cms_cl_index_btn_applynow");
		driver.manage().window().maximize();
		
		//Type of loan
		driver.findElement(By.id("carRelspan")).click();
		driver.findElement(By.linkText("New Car Loan")).click();
		
		//Mobile Number
		driver.findElement(By.id("MOBILENUM")).sendKeys("9818989898");
		
		// First Name 
		driver.findElement(By.id("CUSTFIRSTNAME")).sendKeys("Lalit");
		
		//Last Name 
		driver.findElement(By.id("CUSTLASTNAME")).sendKeys("Bhardwaj");
		
		//Where do you live currently
		   WebElement city = driver.findElement(By.id("CUSTCOMMUCITY"));
	        city.sendKeys("MYS");
	        Thread.sleep(500);
	        city.sendKeys(Keys.ARROW_DOWN);
	        Thread.sleep(500);
	        city.sendKeys(Keys.ENTER);
	        Thread.sleep(500);
	     
	    //Residence Type
	    	driver.findElement(By.id("residancespan")).click();
			driver.findElement(By.linkText("Paying Guest/Hostel")).click();
		
		//When did you move to current  residence
			driver.findElement(By.id("yrspan_mvce")).click();
			driver.findElement(By.linkText("2020")).click();
			driver.findElement(By.id("mnthspan")).click();
			driver.findElement(By.linkText("Apr")).click();
			
			
	        
    	
             //   Date of birth
			driver.findElement(By.id("DATEOFBIRTH")).sendKeys("23081998");
			
			  //Car cost calculation
			
	        WebElement carmod = driver.findElement(By.id("CAR_MODEL_NAME"));
	        carmod.sendKeys("HYU");
	        Thread.sleep(500);
	        carmod.sendKeys(Keys.ARROW_DOWN);
	        Thread.sleep(500);
	        carmod.sendKeys(Keys.ENTER);
	        Thread.sleep(500);
	        
	        WebElement cityname = driver.findElement(By.id("CITY_NAME"));
	        cityname.sendKeys("BANGALOR");
	        Thread.sleep(500);
	        cityname.sendKeys(Keys.ARROW_DOWN);
	        Thread.sleep(500);
	        cityname.sendKeys(Keys.ENTER);
	        Thread.sleep(500);
	        driver.findElement(By.id("CAR_MODEL_PRIZE")).click();
	       
	        // Work Information
	        driver.findElement(By.id("selSalspan")).click();
			driver.findElement(By.linkText("Salaried")).click();
			
			//Company Name
			WebElement companyname  = driver.findElement(By.id("EMPLOYERNAME"));
			companyname.sendKeys("LARSEN AND ");
	        Thread.sleep(500);
	        companyname.sendKeys(Keys.ARROW_DOWN);
	        Thread.sleep(500);
	        companyname.sendKeys(Keys.ENTER);
	        Thread.sleep(500);
	        
	        //SELECT JOINING YEAR
	        driver.findElement(By.id("yrspan_we")).click();
			driver.findElement(By.linkText("2021")).click();
			driver.findElement(By.id("mnthspan_we")).click();
			driver.findElement(By.linkText("Feb")).click();
			
			//total work experience
			driver.findElement(By.id("totalworkexp")).click();
			driver.findElement(By.linkText("<1")).click();
			
			//Month net take Home Salary
			driver.findElement(By.name("MONTHLY_NET_HM_SAL")).sendKeys("30000");
			
			// Gross Annual salary
			driver.findElement(By.name("GROSS_FIXED_M_SAL")).sendKeys("420000");
			
			// Total EMI you pay
			driver.findElement(By.name("TOTAL_CURR_EMI_PAID")).sendKeys("000");
			
			//check Eligibilty
			
			driver.findElement(By.id("eligibility-btn")).click();
			
			
			
			
			
	        
		
		
//		
		
	}

}
