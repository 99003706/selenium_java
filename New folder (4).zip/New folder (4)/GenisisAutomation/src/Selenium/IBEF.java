package Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
	

public class IBEF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("welcome to selenium training");
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Training\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		//Website URL
		driver.get("https://dhtmlx.com/docs/products/dhtmlxTree/");
		
		
		

	}

}
